package wordsCount;

import java.io.IOException;


/**
 * Launcher for the console menu.
 * @author Gregory Lauture
 * @version 1.0
 * @since 2021 -10-27
 */
public class wordCounter {


    public static void main(String[] args) throws IOException {
        menu myMenu= new menu();
        myMenu.menu();
    }
}